/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicio;

import dao.MenuDAO;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Menu;

/**
 *
 * @author giovanny
 */
@WebService(serviceName = "MenuWS")
public class MenuWS {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "IngresarMenu")
    public String IngresarMenu(@WebParam(name = "cod") int cod, @WebParam(name = "nombre") String nombre, @WebParam(name = "precio") String precio, @WebParam(name = "tiempoPreparacion") int tiempoPreparacion, @WebParam(name = "categoria") String categoria, @WebParam(name = "calificacion") Integer calificacion, @WebParam(name = "descripcion") String descripcion) {
        //TODO write your implementation code here:
        Menu m = new Menu(cod, nombre, precio, tiempoPreparacion, categoria, calificacion, descripcion);
        MenuDAO menuDAO= new MenuDAO();
        menuDAO.ingresarMenu(m);
        return "Menu ingresado";
    }
}
